# coding=UTF-8
import socket
from tkinter import *
from GUI import TrainWindow


import torch
from utils import *
from connFun import *
from initDate import *

from torch.utils.data import DataLoader
from argu import Arguments

#端口地址
address = 8887

#IP地址
IP = "127.0.0.1"

#实例化参数类
args = Arguments()


# 固定化随机数种子，使得每次训练的随机数都是固定的
torch.manual_seed(args.seed)

# #创建训练集
train_datasets = MyDataSet('data/NSL-KDD/training_attack_types.txt',"data/NSL-KDD/KDDTrain+_20Percent.txt",SMO=True)
train_loader = DataLoader(train_datasets,batch_size=args.batch_size,shuffle=True)

# #创建测试集
test_datasets = MyDataSet('data/NSL-KDD/training_attack_types.txt',"data/NSL-KDD/KDDTest+.txt",
                                    maxTemp=train_datasets.maxTemp,minTemp=train_datasets.minTemp)
test_loader = DataLoader(test_datasets,batch_size=args.test_batch_size,shuffle=True)

all = sum([x[1] for x in train_datasets.counter.most_common()])
TP = torch.tensor([all/train_datasets.counter["begin"],all/train_datasets.counter["dos"],
                    all/train_datasets.counter["probe"],all/train_datasets.counter["u2r"],
                    all/train_datasets.counter["r2l"]]).log()#TP权重矩阵

if __name__ == '__main__':

    Socket_tcp=socket.socket(socket.AF_INET,socket.SOCK_STREAM)

    Socket_tcp.connect((IP,address))

    model = Net()
    
    try:
        root=Tk()
        root.geometry("1000x650+500+300")
        root.title("基于联邦学习的恶意流量检测系统客户端")
        app = TrainWindow(master=root,socket_tcp = Socket_tcp,model=model,
                train_loader=train_loader,test_loader=test_loader,args=args,TP=TP,trainDateSet=train_datasets)
        root.mainloop()
    finally:
        Socket_tcp.close()