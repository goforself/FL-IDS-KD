class Arguments():
    def __init__(self):
        self.batch_size = 10
        self.test_batch_size = 1
        self.epochs = 1
        self.lr = 0.0001
        self.momentum = 0.5
        self.seed = 10
        self.log_interval = 1
        self.save_model = False